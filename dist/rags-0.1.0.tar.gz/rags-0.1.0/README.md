# rags
a retrieval-augmented generation framework
